public class Streams {
    public static void main(String[] args) {
        List<Integer> names = List.of("Ramoji","Lakshmoji","Vital");
        System.out.println(names);
    }
}

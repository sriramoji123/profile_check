package com.shopunity.user_service.security;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Service;

import com.shopunity.user_service.exception.UserNotFoundException;
import com.shopunity.user_service.repository.UserRepository;
import org.springframework.context.annotation.Lazy;


@Service
@RequiredArgsConstructor
@Slf4j
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private final UserRepository repository;


    @Override
    public UserDetails loadUserByUsername(final String username) throws UserNotFoundException {
       System.out.println("inside loadUserByUserName");
        
        final com.shopunity.user_service.entity.User loggedInUser = this.repository.findByEmail(username);
        if(loggedInUser == null) {
            throw new UserNotFoundException("Unknown user "+ username);
        }
                // Here we are converting the data from db to the UserDetails by converting into UserDetails type(Not the one created as entity)
        return User.withUsername(loggedInUser.getEmail())
                .password(loggedInUser.getPassword())
                // .password("Suseela@2024")
                .authorities(loggedInUser.getRoles().stream().map(role->new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList()))
                .accountExpired(false)
                .accountLocked(false)
                .credentialsExpired(false)
                .disabled(!loggedInUser.isEnabled())
                .build();
    }

    public UserDetailsServiceImpl() {
        this.repository = null;
        //TODO Auto-generated constructor stub
    }



    // the above conversion can aslo be done by creating a new class that implements UserDetails
    

}
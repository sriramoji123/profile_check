package com.shopunity.user_service.exception;

import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalException{

    @ExceptionHandler(value=UserNotFoundException.class)
    public ResponseEntity<ErrorResponse> userNotFoundException(UserNotFoundException ex){
        System.out.println("inside globalexception method");
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse(400,ex.getMessage()));
    }

    // This is mandatory as we are using globalexception handler with 
    // @ControllerAdvice, without the below exception class
    // the code would not show these errors by default in response.
    // It would just fail with 400 or 500 errors.

    @ExceptionHandler(value=MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String,String>> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex){
        Map<String,String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error->{errors.put(error.getField(), error.getDefaultMessage());
        });
        return new ResponseEntity<>(errors,HttpStatus.BAD_REQUEST);
    }
    
}




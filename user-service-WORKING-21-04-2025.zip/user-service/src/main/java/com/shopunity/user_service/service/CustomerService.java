package com.shopunity.user_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopunity.user_service.controller.CustomerRepository;
import com.shopunity.user_service.entity.Customer;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;


    public List<Customer> getAllCustomers() {
        Customer customer = new Customer(2L, "Lakshmoji", "lakshmoji.seemakurthi@gmail.com");
        customerRepository.save(customer);
        return customerRepository.findAll();
    }
}

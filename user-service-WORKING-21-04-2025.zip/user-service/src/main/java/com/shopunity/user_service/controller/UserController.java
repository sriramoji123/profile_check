package com.shopunity.user_service.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopunity.user_service.dto.AuthRequest;
import com.shopunity.user_service.entity.User;
import com.shopunity.user_service.exception.UserNotFoundException;
import com.shopunity.user_service.service.JwtService;
import com.shopunity.user_service.service.UserService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
@RequestMapping("/api/v1/users")
@Slf4j
public class UserController {
    @Autowired
    private UserService userService;
    
    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private ServerProperties serverProperties;

    @PostMapping("/createUser")
    public User CreateUser(@RequestBody @Valid User user){
        return userService.createUser(user);
    }

    @PutMapping("addRoleToUser/user/{userId}/role/{roleId}")
    // @PreAuthorize("hasAuthority('Admin')")
    public User addRoleToUser(@PathVariable Long userId,@PathVariable Integer roleId) {
        return userService.addRoleToUser(userId, roleId);
    }

    @GetMapping("allUsers")
    public List<User> getAllUsers() {
        int port = serverProperties.getPort();
        System.out.println("the port on which users service is running is as follows:");
        System.out.println(port);
        return userService.getAllUsers();
    }

    @PutMapping("removeRoleToUser/user/{userId}/role/{roleId}")
    @PreAuthorize("hasAuthority('Admin')")
    public User removeRoleToUser(@PathVariable Long userId,@PathVariable Integer roleId) {
        return userService.removeRoleToUser(userId, roleId);
    }


    
    @GetMapping("authenticate")
    public String getMethodName(@RequestBody AuthRequest authRequest) {
    Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
    if(authentication.isAuthenticated()){

        log.info("sending details to generate the token");
        return jwtService.generateToken(authRequest.getUsername());
    }  
    throw new UserNotFoundException("Invalid User.");  
}
    

    
}

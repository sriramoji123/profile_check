package com.shopunity.user_service.service;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.shopunity.user_service.entity.Role;
import com.shopunity.user_service.entity.User;
import com.shopunity.user_service.exception.UserNotFoundException;
import com.shopunity.user_service.repository.RoleRepository;
import com.shopunity.user_service.repository.UserRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
	private PasswordEncoder passwordEncoder;

    public User createUser(User user){
        encodePassword(user);
        System.out.println("the password is:");
        System.out.println(user.getPassword());
        return userRepository.save(user);
    }

    public User addRoleToUser(Long userId, Integer roleId){
        User user = userRepository.findById(userId).get();
        Role role = roleRepository.findById(roleId).get();
        user.roles.add(role);
        // user.(false);
        user.setEnabled(true);
        return userRepository.save(user);
    }

    public User removeRoleToUser(Long userId, Integer roleId) throws UserNotFoundException{
        Optional<User> optionalUser = userRepository.findById(userId);
        if(optionalUser.isEmpty())
        {
            throw new UserNotFoundException("User with ID " + userId + " not found");
        }
        User user = optionalUser.get();
        Optional<Role> optionalRole = roleRepository.findById(roleId);
        if(optionalRole.isEmpty())
        {
            throw new EntityNotFoundException("Role with ID " + roleId + " not found");
        }
        Role role = optionalRole.get();
        if(user.getRoles().contains(role)){
            user.roles.remove(role);
        }

        return userRepository.save(user);
    }

    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    private void encodePassword(User user) {
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
	}
}

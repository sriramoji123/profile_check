package com.shopunity.user_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopunity.user_service.entity.Role;
import com.shopunity.user_service.repository.RoleRepository;

@RestController
@RequestMapping("api/v1/roles")
public class RoleController {
	
	@Autowired
	public RoleRepository roleRepository;
	
	@PostMapping("/createRole")
	public Role createRole(@RequestBody Role role) {
		System.out.println("role description is:");
		return roleRepository.save(role);
	}

}

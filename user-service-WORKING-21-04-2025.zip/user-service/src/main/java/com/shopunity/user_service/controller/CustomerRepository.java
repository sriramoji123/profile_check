package com.shopunity.user_service.controller;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shopunity.user_service.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long> {
    // Custom query methods if needed
}